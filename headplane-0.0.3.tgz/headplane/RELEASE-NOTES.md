## [0.0.3] - 2026-10-02

### Changed
- drop scaffold references to other charts

