## [0.0.5] - 2026-10-02

### Fixed
- verify Artifact Hub publisher and use official logo

