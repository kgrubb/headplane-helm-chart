## [0.3.1] - 2026-10-23

### Fixed
- bump Headplane app image to 0.8.2

