## [0.0.4] - 2026-10-02

### Fixed
- harden security context and probes

