## [0.0.6] - 2026-10-02

### Fixed
- always set kubernetes.pod_name in config

