## [0.2.0] - 2026-10-20

### Added
- bump Headplane app image to 0.8.1

